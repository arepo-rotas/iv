
public class GastoException extends Exception {

		public String error() {
		return "Saldo insuficiente";
	}
	
}
